# CodeVerse

A full-stack programming education and collaboration platform built with React, Express, Node.js and MongoDB.

## Features
- Register/login with JWT authentication
- Learning hub with programming courses
- Coding quiz module with score feedback
- Dashboard with learning statistics
- Student project showcase
- Responsive dark interface

## Requirements
- Node.js 18+
- MongoDB local installation or MongoDB Atlas connection

## Setup
1. Extract the ZIP.
2. Open a terminal in the `CodeVerse` folder.
3. Install dependencies:
   ```bash
   npm install
   npm run install:all
   ```
4. Copy `server/.env.example` to `server/.env` and configure `MONGO_URI` and `JWT_SECRET`.
5. Start both applications:
   ```bash
   npm run dev
   ```
6. Open http://localhost:5173

Backend runs at http://localhost:5000. API health: http://localhost:5000/api/health

## Demo mode
The frontend includes a guest preview so the interface can be explored without an account. Authentication and saved progress require a running MongoDB connection.

## Main API routes
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/courses`
- `GET /api/quizzes`
- `POST /api/quizzes/:id/submit`
- `GET /api/dashboard`
- `GET /api/projects`
- `POST /api/projects` (authenticated)

## Project structure
```
CodeVerse/
  client/       React + Vite frontend
  server/       Express API + Mongoose models
```

## Before academic submission
Update the team names, college details, guide name, screenshots and project-specific requirements. Test the application with your actual MongoDB database and document the results. Do not present demo/guest mode as a live production deployment.
