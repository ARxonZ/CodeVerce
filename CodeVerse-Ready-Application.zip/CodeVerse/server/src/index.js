import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { connectDB } from "./config/db.js";
import authRoutes from "./routes/auth.js";
import apiRoutes from "./routes/api.js";

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));
app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "CodeVerse API", timestamp: new Date().toISOString() }));
app.use("/api/auth", authRoutes);
app.use("/api", apiRoutes);
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: "Server error. Check the server logs." });
});

const port = process.env.PORT || 5000;
connectDB().then(() => app.listen(port, () => console.log(`CodeVerse API running on ${port}`)))
  .catch(err => { console.error("Database connection failed:", err.message); process.exit(1); });
