import { Router } from "express";
import { courses } from "../data/courses.js";
import { quizzes } from "../data/quizzes.js";
import { protect } from "../middleware/auth.js";
import Project from "../models/Project.js";

const router = Router();

router.get("/courses", (_req, res) => res.json({ courses }));
router.get("/quizzes", (_req, res) => res.json({ quizzes: quizzes.map(({ id, title, topic, difficulty, questions }) => ({ id, title, topic, difficulty, questionCount: questions.length })) }));

router.post("/quizzes/:id/submit", protect, async (req, res) => {
  const quiz = quizzes.find(q => q.id === req.params.id);
  if (!quiz) return res.status(404).json({ message: "Quiz not found" });
  const answers = req.body.answers;
  if (!Array.isArray(answers) || answers.length !== quiz.questions.length) return res.status(400).json({ message: "Submit one answer for each question" });
  const correct = quiz.questions.reduce((sum, q, i) => sum + (Number(answers[i]) === q.answer ? 1 : 0), 0);
  const points = correct * 10;
  req.user.quizAttempts += 1;
  req.user.totalPoints += points;
  await req.user.save();
  res.json({ score: correct, total: quiz.questions.length, points, results: quiz.questions.map((q, i) => ({ question: q.question, correctAnswer: q.options[q.answer], selectedAnswer: q.options[Number(answers[i])] ?? "Not answered", isCorrect: Number(answers[i]) === q.answer, explanation: q.explanation })) });
});

router.get("/dashboard", protect, async (req, res) => {
  const projects = await Project.countDocuments({ owner: req.user._id });
  res.json({ stats: { points: req.user.totalPoints, completedLessons: req.user.completedLessons.length, quizAttempts: req.user.quizAttempts, projects }, recentActivity: [] });
});

router.post("/lessons/:lessonId/complete", protect, async (req, res) => {
  if (!req.user.completedLessons.includes(req.params.lessonId)) {
    req.user.completedLessons.push(req.params.lessonId);
    await req.user.save();
  }
  res.json({ completedLessons: req.user.completedLessons });
});

router.get("/projects", async (_req, res, next) => {
  try {
    const projects = await Project.find().populate("owner", "name").sort({ createdAt: -1 }).limit(30);
    res.json({ projects });
  } catch (e) { next(e); }
});

router.post("/projects", protect, async (req, res, next) => {
  try {
    const { title, description, techStack = [], link = "" } = req.body;
    if (!title?.trim() || !description?.trim()) return res.status(400).json({ message: "Title and description are required" });
    if (link && !/^https?:\/\//i.test(link)) return res.status(400).json({ message: "Project link must start with http:// or https://" });
    const project = await Project.create({ title: title.trim(), description: description.trim(), techStack: Array.isArray(techStack) ? techStack.slice(0, 8) : [], link, owner: req.user._id });
    await project.populate("owner", "name");
    res.status(201).json({ project });
  } catch (e) { next(e); }
});

export default router;
