export const quizzes = [
  { id: "js-basics", title: "JavaScript Basics", topic: "Programming", difficulty: "Beginner", questions: [
    { question: "Which keyword declares a block-scoped variable that can be reassigned?", options: ["const", "let", "static", "define"], answer: 1, explanation: "`let` declares a block-scoped variable that can be reassigned." },
    { question: "What does `typeof []` return in JavaScript?", options: ["array", "list", "object", "undefined"], answer: 2, explanation: "Arrays are objects in JavaScript, so typeof returns `object`." },
    { question: "Which method adds an item to the end of an array?", options: ["push()", "pop()", "shift()", "slice()"], answer: 0, explanation: "`push()` appends one or more elements to an array." },
    { question: "Which symbol is used for strict equality?", options: ["=", "==", "===", "!="], answer: 2, explanation: "`===` compares value and type without coercion." }
  ]},
  { id: "web-foundations", title: "Web Foundations", topic: "Web Development", difficulty: "Beginner", questions: [
    { question: "What does HTML stand for?", options: ["Hyper Trainer Marking Language", "HyperText Markup Language", "HighText Machine Language", "HyperText Markdown Language"], answer: 1, explanation: "HTML means HyperText Markup Language." },
    { question: "Which CSS property changes text colour?", options: ["font-style", "background", "color", "text-decoration"], answer: 2, explanation: "`color` sets the foreground colour of text." },
    { question: "Which HTTP method is commonly used to retrieve data?", options: ["POST", "PATCH", "DELETE", "GET"], answer: 3, explanation: "`GET` requests a representation of a resource." }
  ]}
];
