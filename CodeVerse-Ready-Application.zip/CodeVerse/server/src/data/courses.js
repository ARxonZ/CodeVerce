export const courses = [
  { id: "html-foundations", title: "HTML Foundations", category: "Frontend", level: "Beginner", duration: "3.5 hours", lessons: 12, description: "Build the structure of the web with semantic HTML.", color: "violet", icon: "◇" },
  { id: "css-modern", title: "Modern CSS", category: "Frontend", level: "Beginner", duration: "5 hours", lessons: 16, description: "Create responsive layouts, animations and polished interfaces.", color: "blue", icon: "▧" },
  { id: "javascript-core", title: "JavaScript Core", category: "Programming", level: "Intermediate", duration: "8 hours", lessons: 24, description: "Learn variables, functions, arrays, objects and asynchronous code.", color: "amber", icon: "JS" },
  { id: "react-start", title: "React Essentials", category: "Frontend", level: "Intermediate", duration: "6 hours", lessons: 18, description: "Build component-driven applications with hooks and state.", color: "cyan", icon: "⚛" },
  { id: "node-api", title: "Node.js & APIs", category: "Backend", level: "Intermediate", duration: "7 hours", lessons: 20, description: "Create REST APIs, middleware and server-side applications.", color: "green", icon: "⌘" },
  { id: "python-logic", title: "Python Logic", category: "Programming", level: "Beginner", duration: "4 hours", lessons: 14, description: "Develop problem-solving skills with clean Python code.", color: "blue", icon: "Py" }
];
