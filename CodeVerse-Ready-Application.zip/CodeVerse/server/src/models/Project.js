import mongoose from "mongoose";

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 90 },
  description: { type: String, required: true, maxlength: 600 },
  techStack: [{ type: String, trim: true }],
  link: { type: String, default: "" },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

export default mongoose.model("Project", projectSchema);
